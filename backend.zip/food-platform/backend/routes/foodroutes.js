const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");

const {
  addFood,
  getRestaurantHistory,
  checkPremiumStatus
} = require("../controllers/foodController");

router.post("/add", auth, addFood);
router.get("/history", auth, getRestaurantHistory);
router.get("/premium", auth, checkPremiumStatus);

module.exports = router;
