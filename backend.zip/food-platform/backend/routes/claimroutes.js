const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const { claimFood } = require("../controllers/claimController");

router.post("/add", auth, claimFood);

module.exports = router;
