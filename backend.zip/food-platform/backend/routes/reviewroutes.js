const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const { addReview, getRestaurantReviews } = require("../controllers/reviewController");

router.post("/add", auth, addReview);
router.get("/:id", getRestaurantReviews);

module.exports = router;
