const mongoose = require("mongoose");

const claimSchema = new mongoose.Schema({
  food_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Food"
  },
  ngo_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
  },
  claimed_servings: Number
}, { timestamps: true });

module.exports = mongoose.model("Claim", claimSchema);
