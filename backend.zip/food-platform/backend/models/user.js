const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  role: {
    type: String,
    enum: ["restaurant", "ngo", "admin"],
    required: true
  },
  status: {
    type: String,
    enum: ["pending", "approved"],
    default: "pending"
  },
  document_url: String,
  is_premium: {
    type: Boolean,
    default: false
  }
}, { timestamps: true });

module.exports = mongoose.model("User", userSchema);
