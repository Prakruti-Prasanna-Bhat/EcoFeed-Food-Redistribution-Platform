const mongoose = require("mongoose");

const foodSchema = new mongoose.Schema({
  restaurant_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
  },
  food_name: String,
  total_servings: Number,
  available_servings: Number,
  expiry_time: Date
}, { timestamps: true });

module.exports = mongoose.model("Food", foodSchema);
