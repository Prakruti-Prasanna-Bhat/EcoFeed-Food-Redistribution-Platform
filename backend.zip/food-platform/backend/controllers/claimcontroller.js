const Claim = require("../models/Claim");
const Food = require("../models/Food");

exports.claimFood = async (req, res) => {
  const { food_id, claimed_servings } = req.body;

  const food = await Food.findById(food_id);
  if (!food) return res.status(404).json({ message: "Food not found" });

  if (food.available_servings < claimed_servings) {
    return res.status(400).json({ message: "Not enough servings available" });
  }

  // Reduce available servings
  food.available_servings -= claimed_servings;
  await food.save();

  // Create claim record
  const claim = await Claim.create({
    food_id,
    ngo_id: req.user.id,
    claimed_servings
  });

  res.json({ message: "Food claimed successfully", claim });
};
