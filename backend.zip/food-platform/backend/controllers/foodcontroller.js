const Food = require("../models/Food");
const Claim = require("../models/Claim");
const User = require("../models/User");


// =======================
// ADD FOOD
// =======================
exports.addFood = async (req, res) => {
  try {
    const food = await Food.create({
      restaurant_id: req.user.id,
      food_name: req.body.food_name,
      total_servings: req.body.total_servings,
      available_servings: req.body.total_servings,
      expiry_time: req.body.expiry_time
    });

    res.json(food);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// =======================
// RESTAURANT HISTORY
// =======================
exports.getRestaurantHistory = async (req, res) => {
  try {
    const foods = await Food.find({ restaurant_id: req.user.id });

    const result = [];

    for (let food of foods) {

      // Get claims
      const claims = await Claim.find({ food_id: food._id })
        .populate("ngo_id", "name");

      // Calculate total claimed
      const totalClaimed = claims.reduce(
        (sum, claim) => sum + claim.claimed_servings,
        0
      );

      // Determine status
      let status = "Available";

      if (new Date(food.expiry_time) < new Date()) {
        status = "Expired";
      } else if (totalClaimed === 0) {
        status = "Available";
      } else if (totalClaimed < food.total_servings) {
        status = "Partially Claimed";
      } else if (totalClaimed >= food.total_servings) {
        status = "Fully Claimed";
      }

      result.push({
        id: food._id,
        food_name: food.food_name,
        total_servings: food.total_servings,
        available_servings: food.available_servings,
        expiry_time: food.expiry_time,
        status,
        claims: claims.map(c => ({
          ngo_name: c.ngo_id.name,
          claimed_servings: c.claimed_servings
        }))
      });
    }

    res.json(result);

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// =======================
// PREMIUM DONOR LOGIC
// =======================
exports.checkPremiumStatus = async (req, res) => {
  try {
    const totalUploads = await Food.countDocuments({
      restaurant_id: req.user.id
    });

    let premium = false;

    // Example logic: more than 5 uploads = premium
    if (totalUploads >= 5) {
      premium = true;
    }

    res.json({
      total_uploads: totalUploads,
      premium_status: premium
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
