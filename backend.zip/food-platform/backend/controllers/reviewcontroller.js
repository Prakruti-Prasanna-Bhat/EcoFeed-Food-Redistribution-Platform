const Review = require("../models/Review");

exports.addReview = async (req, res) => {
  try {
    const review = await Review.create({
      restaurant_id: req.body.restaurant_id,
      ngo_id: req.user.id,
      rating: req.body.rating,
      comment: req.body.comment
    });

    res.json(review);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getRestaurantReviews = async (req, res) => {
  try {
    const reviews = await Review.find({
      restaurant_id: req.params.id
    }).populate("ngo_id", "name");

    res.json(reviews);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
